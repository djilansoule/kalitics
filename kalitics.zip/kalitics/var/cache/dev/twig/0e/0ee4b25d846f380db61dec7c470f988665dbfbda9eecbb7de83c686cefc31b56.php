<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* team/index.html.twig */
class __TwigTemplate_9b511c6ca80857999bc22dbb24fb4f421ee860f60182ddbec0297cf6aac34e19 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "team/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "team/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Team index";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <style>
        .paginate_button{
            cursor: pointer !important;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 13
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "    <h1>Team index</h1>

    <div id=\"contain\">
        ";
        // line 17
        $this->loadTemplate("team/table.html.twig", "team/index.html.twig", 17)->display($context);
        // line 18
        echo "    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 21
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 22
        echo "    <script>
        //Initialisation du tableau avec les valeurs venant côté serveur en ajax
        \$(window).bind(\"load\", function() {
            var limit = \$(\"select[name='table_length']\").val();
            ajaxTableLength(limit, 0, 0, 0, 0);
        });

        //Appel côté serveur pour changer le nombre d'élément dans la page
        \$(function(){
            var max_team_id = getMaxTeamId();
            \$(\"#contain\").on('change', \"select[name='table_length']\", function(e) {
                var limit = \$(\"select[name='table_length']\").val();
                ajaxTableLength(limit, 0, 0, 0, 0);
            });

            //Clique sur le bouton next
            \$('#contain').on('click', '.next', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                ajaxTableLength(limit, 2, getMaxTeamId(), 0, 0);

            });

            //Clique sur le bouton prev
            \$('#contain').on('click', '.prev', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                var max_team_id = getMaxTeamId();
                ajaxTableLength(limit, 1, 0, getMinTeamId(max_team_id),0);
            });

            //Clique sur le bouton filter-name
            \$('#contain').on('click', '.filter-name', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                var max_team_id = getMaxTeamId();
                if(\$(\".filter-name\").hasClass(\"active\")){
                    ajaxTableLength(limit, 0, 0, getMinTeamId(max_team_id), 'name_asc');
                }else{
                    ajaxTableLength(limit, 0, 0, getMinTeamId(max_team_id), 'name_desc');
                }

            });
        });

        //Fonction ajax permettant de gérer le nombre d'élément dans la page
        function ajaxTableLength(limit, pagination, max_team_id, min_team_id, filter){
            \$.ajax({
                url: getRoot() + 'team',
                type: 'GET',
                data: {
                    'limit': limit,
                    'pagination' : pagination,
                    'max_team_id': max_team_id,
                    'min_team_id': min_team_id,
                    'filter': filter
                },
                success: function(serverResponse){
                    \$(\"#contain\").html(serverResponse);
                    \$(\"select[name='table_length']\").val(limit);
                    if(pagination == 2){
                        \$(\".prev\").prop(\"disabled\", false);
                    }

                    if(filter == 'name_desc'){
                        \$(\".filter-name\").toggleClass(\"active\");
                    }

                }
            });
        }

        function getMaxTeamId(){
            //Récupération du max teams_id
            var first_team_id = 0;
            \$('.team-id').each(function(){
                if(parseInt(\$(this).text()) > first_team_id){
                    first_team_id = parseInt(\$(this).text()) ;
                }
            });

            return first_team_id;
        }

        function getMinTeamId(last_team_id){
            //Récupération du max teams_id
            \$('.team-id').each(function(){
                if(parseInt(\$(this).text()) < last_team_id){
                    last_team_id = parseInt(\$(this).text()) ;
                }
            });
            console.log(last_team_id);

            return last_team_id;
        }
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "team/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 22,  109 => 21,  101 => 18,  99 => 17,  94 => 14,  87 => 13,  75 => 6,  68 => 5,  55 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Team index{% endblock %}

{% block stylesheets %}
    <style>
        .paginate_button{
            cursor: pointer !important;
        }
    </style>
{% endblock %}

{% block body %}
    <h1>Team index</h1>

    <div id=\"contain\">
        {% include('team/table.html.twig') %}
    </div>
{% endblock %}

{% block javascripts %}
    <script>
        //Initialisation du tableau avec les valeurs venant côté serveur en ajax
        \$(window).bind(\"load\", function() {
            var limit = \$(\"select[name='table_length']\").val();
            ajaxTableLength(limit, 0, 0, 0, 0);
        });

        //Appel côté serveur pour changer le nombre d'élément dans la page
        \$(function(){
            var max_team_id = getMaxTeamId();
            \$(\"#contain\").on('change', \"select[name='table_length']\", function(e) {
                var limit = \$(\"select[name='table_length']\").val();
                ajaxTableLength(limit, 0, 0, 0, 0);
            });

            //Clique sur le bouton next
            \$('#contain').on('click', '.next', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                ajaxTableLength(limit, 2, getMaxTeamId(), 0, 0);

            });

            //Clique sur le bouton prev
            \$('#contain').on('click', '.prev', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                var max_team_id = getMaxTeamId();
                ajaxTableLength(limit, 1, 0, getMinTeamId(max_team_id),0);
            });

            //Clique sur le bouton filter-name
            \$('#contain').on('click', '.filter-name', function(){
                //2 pour next et 1 pour prev
                var limit = \$(\"select[name='table_length']\").val();
                var max_team_id = getMaxTeamId();
                if(\$(\".filter-name\").hasClass(\"active\")){
                    ajaxTableLength(limit, 0, 0, getMinTeamId(max_team_id), 'name_asc');
                }else{
                    ajaxTableLength(limit, 0, 0, getMinTeamId(max_team_id), 'name_desc');
                }

            });
        });

        //Fonction ajax permettant de gérer le nombre d'élément dans la page
        function ajaxTableLength(limit, pagination, max_team_id, min_team_id, filter){
            \$.ajax({
                url: getRoot() + 'team',
                type: 'GET',
                data: {
                    'limit': limit,
                    'pagination' : pagination,
                    'max_team_id': max_team_id,
                    'min_team_id': min_team_id,
                    'filter': filter
                },
                success: function(serverResponse){
                    \$(\"#contain\").html(serverResponse);
                    \$(\"select[name='table_length']\").val(limit);
                    if(pagination == 2){
                        \$(\".prev\").prop(\"disabled\", false);
                    }

                    if(filter == 'name_desc'){
                        \$(\".filter-name\").toggleClass(\"active\");
                    }

                }
            });
        }

        function getMaxTeamId(){
            //Récupération du max teams_id
            var first_team_id = 0;
            \$('.team-id').each(function(){
                if(parseInt(\$(this).text()) > first_team_id){
                    first_team_id = parseInt(\$(this).text()) ;
                }
            });

            return first_team_id;
        }

        function getMinTeamId(last_team_id){
            //Récupération du max teams_id
            \$('.team-id').each(function(){
                if(parseInt(\$(this).text()) < last_team_id){
                    last_team_id = parseInt(\$(this).text()) ;
                }
            });
            console.log(last_team_id);

            return last_team_id;
        }
    </script>
{% endblock %}
", "team/index.html.twig", "C:\\xampp\\htdocs\\kalitics\\templates\\team\\index.html.twig");
    }
}
