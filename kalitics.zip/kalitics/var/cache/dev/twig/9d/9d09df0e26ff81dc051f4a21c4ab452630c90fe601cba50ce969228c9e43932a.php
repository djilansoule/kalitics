<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* team/table.html.twig */
class __TwigTemplate_d22f40dc5c56950200cf239246b4fea9a630ebb667101de1bdb59c80fcb8c9e9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "team/table.html.twig"));

        // line 1
        echo "<select name=\"table_length\" id=\"\">
    <option value=\"10\">10</option>
    <option value=\"25\">25</option>
    <option value=\"50\">50</option>
    <option value=\"100\">100</option>
</select>
<table class=\"display\" style=\"width:100%\">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name <i class=\"fas fa-arrows-alt-v filter-name\" style=\"cursor: pointer\"></i></th>
        <th>PlayerNumber</th>
        <th>BestPlayer</th>
        <th>GoalNumber</th>
        <th>actions</th>
    </tr>
    </thead>
    <tbody>
    ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["teams"]) || array_key_exists("teams", $context) ? $context["teams"] : (function () { throw new RuntimeError('Variable "teams" does not exist.', 19, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["team"]) {
            // line 20
            echo "        <tr>
            <td class=\"team-id\">";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 21), "html", null, true);
            echo "</td>
            <td>";
            // line 22
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "name", [], "any", false, false, false, 22), "html", null, true);
            echo "</td>
            <td>";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "playerNumber", [], "any", false, false, false, 23), "html", null, true);
            echo "</td>
            <td>";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "bestPlayer", [], "any", false, false, false, 24), "html", null, true);
            echo "</td>
            <td>";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "goalNumber", [], "any", false, false, false, 25), "html", null, true);
            echo "</td>
            <td>
                <a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_show", ["id" => twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 27)]), "html", null, true);
            echo "\">show</a>
                <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 28)]), "html", null, true);
            echo "\">edit</a>
            </td>
        </tr>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 32
            echo "        <tr>
            <td colspan=\"6\">no records found</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['team'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "    </tbody>
</table>
<div>
    <button class=\"prev\" disabled>prev</button>
    <button class=\"next\">next</button>
</div>
<a href=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_new");
        echo "\">Create new</a>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "team/table.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 42,  111 => 36,  102 => 32,  93 => 28,  89 => 27,  84 => 25,  80 => 24,  76 => 23,  72 => 22,  68 => 21,  65 => 20,  60 => 19,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<select name=\"table_length\" id=\"\">
    <option value=\"10\">10</option>
    <option value=\"25\">25</option>
    <option value=\"50\">50</option>
    <option value=\"100\">100</option>
</select>
<table class=\"display\" style=\"width:100%\">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name <i class=\"fas fa-arrows-alt-v filter-name\" style=\"cursor: pointer\"></i></th>
        <th>PlayerNumber</th>
        <th>BestPlayer</th>
        <th>GoalNumber</th>
        <th>actions</th>
    </tr>
    </thead>
    <tbody>
    {% for team in teams %}
        <tr>
            <td class=\"team-id\">{{ team.id }}</td>
            <td>{{ team.name }}</td>
            <td>{{ team.playerNumber }}</td>
            <td>{{ team.bestPlayer }}</td>
            <td>{{ team.goalNumber }}</td>
            <td>
                <a href=\"{{ path('team_show', {'id': team.id}) }}\">show</a>
                <a href=\"{{ path('team_edit', {'id': team.id}) }}\">edit</a>
            </td>
        </tr>
    {% else %}
        <tr>
            <td colspan=\"6\">no records found</td>
        </tr>
    {% endfor %}
    </tbody>
</table>
<div>
    <button class=\"prev\" disabled>prev</button>
    <button class=\"next\">next</button>
</div>
<a href=\"{{ path('team_new') }}\">Create new</a>", "team/table.html.twig", "C:\\xampp\\htdocs\\kalitics\\templates\\team\\table.html.twig");
    }
}
