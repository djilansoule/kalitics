<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* team/table.html.twig */
class __TwigTemplate_d22f40dc5c56950200cf239246b4fea9a630ebb667101de1bdb59c80fcb8c9e9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "team/table.html.twig"));

        // line 1
        echo "<table id=\"table\" class=\"display\" style=\"width:100%\">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>PlayerNumber</th>
        <th>BestPlayer</th>
        <th>GoalNumber</th>
        <th>actions</th>
    </tr>
    </thead>
    <tbody>
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["teams"]) || array_key_exists("teams", $context) ? $context["teams"] : (function () { throw new RuntimeError('Variable "teams" does not exist.', 13, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["team"]) {
            // line 14
            echo "        <tr>
            <td>";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 15), "html", null, true);
            echo "</td>
            <td>";
            // line 16
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "name", [], "any", false, false, false, 16), "html", null, true);
            echo "</td>
            <td>";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "playerNumber", [], "any", false, false, false, 17), "html", null, true);
            echo "</td>
            <td>";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "bestPlayer", [], "any", false, false, false, 18), "html", null, true);
            echo "</td>
            <td>";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["team"], "goalNumber", [], "any", false, false, false, 19), "html", null, true);
            echo "</td>
            <td>
                <a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_show", ["id" => twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 21)]), "html", null, true);
            echo "\">show</a>
                <a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 22)]), "html", null, true);
            echo "\">edit</a>
            </td>
        </tr>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 26
            echo "        <tr>
            <td colspan=\"6\">no records found</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['team'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "    </tbody>
</table>

<a href=\"";
        // line 33
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("team_new");
        echo "\">Create new</a>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "team/table.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 33,  105 => 30,  96 => 26,  87 => 22,  83 => 21,  78 => 19,  74 => 18,  70 => 17,  66 => 16,  62 => 15,  59 => 14,  54 => 13,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<table id=\"table\" class=\"display\" style=\"width:100%\">
    <thead>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>PlayerNumber</th>
        <th>BestPlayer</th>
        <th>GoalNumber</th>
        <th>actions</th>
    </tr>
    </thead>
    <tbody>
    {% for team in teams %}
        <tr>
            <td>{{ team.id }}</td>
            <td>{{ team.name }}</td>
            <td>{{ team.playerNumber }}</td>
            <td>{{ team.bestPlayer }}</td>
            <td>{{ team.goalNumber }}</td>
            <td>
                <a href=\"{{ path('team_show', {'id': team.id}) }}\">show</a>
                <a href=\"{{ path('team_edit', {'id': team.id}) }}\">edit</a>
            </td>
        </tr>
    {% else %}
        <tr>
            <td colspan=\"6\">no records found</td>
        </tr>
    {% endfor %}
    </tbody>
</table>

<a href=\"{{ path('team_new') }}\">Create new</a>", "team/table.html.twig", "C:\\xampp\\htdocs\\kalitics\\templates\\team\\table.html.twig");
    }
}
