<?php

namespace App\Repository;

use App\Entity\Team;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Common\Persistence\ManagerRegistry;

/**
 * @method Team|null find($id, $lockMode = null, $lockVersion = null)
 * @method Team|null findOneBy(array $criteria, array $orderBy = null)
 * @method Team[]    findAll()
 * @method Team[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TeamRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Team::class);
    }

    // /**
    //  * @return Team[] Returns an array of Team objects
    //  */

    public function getTeams($limit, $pagination, $max_team_id, $min_team_id, $filter)
    {
        $result = $this->createQueryBuilder('t');
        if($pagination == 2){
            $result->andWhere('t.id > :max')
                ->setParameter('max', $max_team_id);
        }

        if($pagination == 1){
            $result->andWhere('t.id < :min')
                ->setParameter('min', $min_team_id);
        }

        if($filter == 'name_asc'){
            $result->orderBy('t.name', 'ASC');
        }

        if($filter == 'name_desc'){
            $result->orderBy('t.name', 'DESC');
        }

        $result->setMaxResults($limit);

        return $result->getQuery()->getResult();
    }


    /*
    public function findOneBySomeField($value): ?Team
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
